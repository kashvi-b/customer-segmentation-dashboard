import streamlit as st
import plotly.express as px
import plotly.graph_objects as go
import pandas as pd

from segmentation import generate_sample_data, run_segmentation, get_segment_summary
from ai_insights import get_segment_insight, generate_campaign_email

# ── Page config ──────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="AI Customer Segmentation",
    page_icon="📊",
    layout="wide",
)

st.title("📊 AI-Powered Customer Segmentation")
st.caption("Segment your customers with ML · Get marketing insights from Claude AI")

# ── Sidebar ───────────────────────────────────────────────────────────────────
with st.sidebar:
    st.header("⚙️ Settings")
    n_clusters = st.slider("Number of segments", min_value=2, max_value=8, value=5)
    n_customers = st.slider("Sample customers", min_value=100, max_value=1000, value=300, step=50)
    st.divider()
    st.markdown("**How it works**")
    st.markdown(
        "1. Generates sample customer data\n"
        "2. Runs K-Means clustering (ML)\n"
        "3. Labels segments by spend rank\n"
        "4. Claude AI adds insights"
    )

# ── Run segmentation ──────────────────────────────────────────────────────────
if st.button("🚀 Run Segmentation", type="primary", use_container_width=True):
    with st.spinner("Running ML segmentation..."):
        df = generate_sample_data(n_customers)
        df = run_segmentation(df, n_clusters)
        st.session_state["df"] = df
        st.session_state["summary"] = get_segment_summary(df)
    st.success(f"✅ Segmented {n_customers} customers into {n_clusters} groups!")

# ── Main dashboard ────────────────────────────────────────────────────────────
if "df" not in st.session_state:
    st.info("👆 Click **Run Segmentation** to get started.")
    st.stop()

df: pd.DataFrame = st.session_state["df"]
summary: pd.DataFrame = st.session_state["summary"]

# Metric cards
st.subheader("Segment Overview")
cols = st.columns(len(summary))
colors = ["#7F77DD", "#1D9E75", "#D85A30", "#378ADD", "#BA7517", "#D4537E", "#639922", "#888780"]
for i, (_, row) in enumerate(summary.iterrows()):
    with cols[i]:
        st.metric(
            label=row["segment_label"],
            value=f"{int(row['count'])} customers",
            delta=f"${row['avg_spend']:.0f} avg spend",
        )

st.divider()

# Charts
col1, col2 = st.columns(2)

with col1:
    fig_pie = px.pie(
        summary,
        names="segment_label",
        values="count",
        title="Customer distribution by segment",
        color_discrete_sequence=colors,
        hole=0.35,
    )
    fig_pie.update_layout(margin=dict(t=40, b=0, l=0, r=0))
    st.plotly_chart(fig_pie, use_container_width=True)

with col2:
    fig_bar = px.bar(
        summary,
        x="segment_label",
        y="avg_spend",
        color="segment_label",
        title="Average total spend per segment",
        color_discrete_sequence=colors,
        labels={"avg_spend": "Avg spend ($)", "segment_label": "Segment"},
    )
    fig_bar.update_layout(showlegend=False, margin=dict(t=40, b=0))
    st.plotly_chart(fig_bar, use_container_width=True)

# Scatter plot
st.subheader("Customer Map")
fig_scatter = px.scatter(
    df,
    x="total_spend",
    y="purchase_frequency",
    color="segment_label",
    size="avg_order_value",
    hover_data=["customer_id", "days_since_last_purchase"],
    title="Spend vs. Purchase frequency (bubble size = avg order value)",
    color_discrete_sequence=colors,
    labels={
        "total_spend": "Total spend ($)",
        "purchase_frequency": "Purchase frequency",
        "segment_label": "Segment",
    },
)
fig_scatter.update_layout(margin=dict(t=40, b=0))
st.plotly_chart(fig_scatter, use_container_width=True)

st.divider()

# ── AI Insights ───────────────────────────────────────────────────────────────
st.subheader("🤖 AI Marketing Insights")

selected_segment = st.selectbox(
    "Choose a segment to analyse",
    options=summary["segment_label"].tolist(),
)

row = summary[summary["segment_label"] == selected_segment].iloc[0]

col_a, col_b = st.columns(2)

with col_a:
    if st.button("💡 Get Segment Insights", use_container_width=True):
        with st.spinner("Asking Claude AI..."):
            insight = get_segment_insight(
                segment_name=selected_segment,
                avg_spend=row["avg_spend"],
                avg_frequency=row["avg_frequency"],
                count=int(row["count"]),
                avg_recency=row["avg_recency"],
            )
        st.session_state["insight"] = insight

with col_b:
    if st.button("✉️ Generate Campaign Email", use_container_width=True):
        with st.spinner("Claude is writing your email..."):
            email = generate_campaign_email(
                segment_name=selected_segment,
                avg_spend=row["avg_spend"],
                avg_frequency=row["avg_frequency"],
            )
        st.session_state["email"] = email

if "insight" in st.session_state:
    st.info(st.session_state["insight"])

if "email" in st.session_state:
    st.subheader("Generated Email")
    st.text_area("Email body (copy and use)", st.session_state["email"], height=200)

st.divider()

# ── Raw data ──────────────────────────────────────────────────────────────────
with st.expander("🔍 View raw customer data"):
    st.dataframe(
        df.style.format({
            "total_spend": "${:.0f}",
            "avg_order_value": "${:.0f}",
            "purchase_frequency": "{:.0f}",
            "days_since_last_purchase": "{:.0f} days",
        }),
        use_container_width=True,
    )
    csv = df.to_csv(index=False)
    st.download_button(
        "⬇️ Download CSV",
        data=csv,
        file_name="segmented_customers.csv",
        mime="text/csv",
    )
