import os
import anthropic
from dotenv import load_dotenv

load_dotenv()

client = anthropic.Anthropic(api_key=os.getenv("ANTHROPIC_API_KEY"))


def get_segment_insight(segment_name: str, avg_spend: float,
                        avg_frequency: float, count: int,
                        avg_recency: float) -> str:
    """Call Claude API to get marketing insight for a customer segment."""
    prompt = f"""
You are a senior marketing analyst. Analyze this customer segment and give practical advice.

Segment: '{segment_name}'
- Customers: {count}
- Avg total spend: ${avg_spend:.0f}
- Avg purchase frequency: {avg_frequency:.1f} times/year
- Avg days since last purchase: {avg_recency:.0f} days

Provide:
1. PROFILE: A 2-sentence description of who these customers are
2. ACTION: One specific marketing action to take right now
3. EMAIL SUBJECT: A compelling email subject line for this segment

Keep it concise and practical. Use plain text, no bullet symbols or markdown.
"""
    msg = client.messages.create(
        model="claude-sonnet-4-20250514",
        max_tokens=400,
        messages=[{"role": "user", "content": prompt}]
    )
    return msg.content[0].text


def generate_campaign_email(segment_name: str, avg_spend: float,
                             avg_frequency: float) -> str:
    """Generate a short marketing email body for a segment."""
    prompt = f"""
Write a short, personalized marketing email for the '{segment_name}' customer segment.
These customers have an average spend of ${avg_spend:.0f} and purchase {avg_frequency:.1f} times/year.

Write ONLY the email body (3-4 short paragraphs). No subject line, no greeting placeholder.
Make it warm, conversational, and persuasive. Plain text only.
"""
    msg = client.messages.create(
        model="claude-sonnet-4-20250514",
        max_tokens=400,
        messages=[{"role": "user", "content": prompt}]
    )
    return msg.content[0].text
